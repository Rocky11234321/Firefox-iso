#!/usr/bin/env bash
set -euo pipefail

if [[ "${EUID}" -ne 0 ]]; then
  echo "Run as root: sudo ./build.sh" >&2
  exit 1
fi
for cmd in lb xorriso mksquashfs; do
  command -v "$cmd" >/dev/null || { echo "Missing build dependency: $cmd" >&2; exit 1; }
done

WORKDIR="$(cd "$(dirname "$0")" && pwd)"
BUILD="$WORKDIR/work"
mkdir -p "$BUILD"
cd "$BUILD"
rm -rf config chroot binary cache
cp -a "$WORKDIR/config/." "$BUILD/config/"

# Debian 12 still supports a complete i386 userspace/kernel build.
lb config \
  --mode debian \
  --distribution bookworm \
  --architectures i386 \
  --binary-images iso-hybrid \
  --bootloaders grub-pc \
  --archive-areas "main contrib non-free non-free-firmware" \
  --debian-installer false \
  --linux-packages linux-image \
  --linux-flavours 686-pae \
  --mirror-bootstrap https://deb.debian.org/debian \
  --mirror-chroot https://deb.debian.org/debian \
  --mirror-binary https://deb.debian.org/debian \
  --bootappend-live "boot=live components quiet username=browser hostname=firefoxos"

lb build
ISO="$(find "$BUILD" -maxdepth 1 -type f \( -name '*.hybrid.iso' -o -name '*.iso' \) -print -quit)"
if [[ -z "$ISO" ]]; then
  echo "Build completed but no ISO was found in $BUILD" >&2
  exit 1
fi
cp -f "$ISO" "$WORKDIR/FirefoxOS-v86-i386.iso"
echo "Created $WORKDIR/FirefoxOS-v86-i386.iso"
ls -lh "$WORKDIR/FirefoxOS-v86-i386.iso"
