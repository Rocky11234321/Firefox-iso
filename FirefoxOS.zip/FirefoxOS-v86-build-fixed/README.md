# FirefoxOS for v86 — 32-bit x86

This project builds a Debian Live ISO intended for the v86 PC emulator. It is configured to log in automatically, start a minimal Openbox X session, and launch Firefox ESR.

## Important networking note

v86 does not emulate a physical Wi-Fi card. The guest uses an emulated NE2000 Ethernet adapter. Internet access requires a compatible WebSocket Ethernet relay configured in the v86 host page. This ISO cannot make a physical Wi-Fi adapter appear inside v86.

## Easiest build: GitHub Actions

1. Create a new GitHub repository.
2. Upload the contents of this folder to the repository (including the hidden `.github` folder).
3. Open the repository's **Actions** tab.
4. Select **Build FirefoxOS v86 ISO**.
5. Click **Run workflow**.
6. When it finishes, open the run and download the `FirefoxOS-v86-i386-ISO` artifact.
7. Extract the artifact ZIP; it contains `FirefoxOS-v86-i386.iso`.

The workflow runs on an Ubuntu GitHub-hosted runner and downloads Debian packages during the build. Build time and artifact size depend on Debian mirrors and package versions.

## Build locally on Debian 12

Install dependencies:

```bash
sudo apt update
sudo apt install -y live-build debootstrap xorriso squashfs-tools \
  grub-pc-bin syslinux-common syslinux-utils isolinux
```

Then run:

```bash
chmod +x build.sh
sudo ./build.sh
```

The output is `FirefoxOS-v86-i386.iso` in this folder.

## v86 settings

- Architecture: 32-bit x86 PC
- RAM: start with 512 MiB; use more if the host allows it
- Network device: NE2000
- Network relay: configure a trusted, compatible WebSocket Ethernet relay in the v86 host page
- Boot from the ISO as CD-ROM

A public relay may be unavailable, slow, or rate-limited. A self-hosted relay is more reliable. Browser performance in v86 will be significantly slower than on real hardware.

## Notes

- This is a live image; changes may not persist across reboot unless a writable disk/persistence layer is configured.
- Firefox ESR availability and exact version depend on Debian 12 repository state when the ISO is built.
- This is a minimal Openbox session rather than a full desktop environment.
