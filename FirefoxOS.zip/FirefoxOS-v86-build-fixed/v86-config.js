// Example settings for copy.sh/v86 or a self-hosted v86 page.
// Upload FirefoxOS-v86-i386.iso as the CD-ROM image.
// Keep the NE2000 device enabled and use a WebSocket network relay.
const options = {
  memory_size: 512 * 1024 * 1024,
  vga_memory_size: 8 * 1024 * 1024,
  cdrom: { url: "FirefoxOS-v86-i386.iso" },
  net_device: {
    type: "ne2k",
    relay_url: "wss://relay.widgetry.org/"
  },
  autostart: true
};
